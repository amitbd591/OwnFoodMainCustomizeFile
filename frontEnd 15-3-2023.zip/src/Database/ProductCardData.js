const ProductCardData = [
  {
    title: "Lorem Ipsum is simply dummy text of the printing ",
    img: "https://res.cloudinary.com/amitjs/image/upload/v1672241752/Other/convenience_spxrqq.png",
    btn: "Visit More",
    bgColor: "Purple",
  },
  {
    title: "Lorem Ipsum is simply dummy text of the printing",
    img: "https://res.cloudinary.com/amitjs/image/upload/v1672243272/Other/uber_grocery-removebg-preview_bi2myh.png",
    btn: "Visit More",
    bgColor: "Pink",
  },
  {
    title: "Lorem Ipsum is simply dummy text of the printing",
    img: "https://res.cloudinary.com/amitjs/image/upload/v1672243428/Other/fastfood-removebg-preview_dkk59r.png",
    btn: "Visit More",
    bgColor: "Green",
  },
  {
    title: "Lorem Ipsum is simply dummy text of the printing ",
    img: "https://res.cloudinary.com/amitjs/image/upload/v1672243515/Other/korean-removebg-preview_lud2pf.png",
    btn: "Visit More",
    bgColor: "Orange",
  },
];

export default ProductCardData;
