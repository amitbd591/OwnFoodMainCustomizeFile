export const Uber_image = [
  {
    item_name: "Asian",
    item_image: "/Assets/Img/uber_Image/asian.png",
  },
  {
    item_name: "Name",
    item_image: "/Assets/Img/uber_Image/uber_Img.png",
  },
  {
    item_name: "Coffee & Tea",
    item_image: "/Assets/Img/uber_Image/coffeeandtea.png",
  },
  {
    item_name: "Convenience",
    item_image: "/Assets/Img/uber_Image/convenience.png",
  },
  {
    item_name: "FastFood",
    item_image: "/Assets/Img/uber_Image/fastfood.png",
  },
  {
    item_name: "Indian",
    item_image: "/Assets/Img/uber_Image/indian.png",
  },
  {
    item_name: "Italian",
    item_image: "/Assets/Img/uber_Image/italian.png",
  },
  {
    item_name: "SeaFood",
    item_image: "/Assets/Img/uber_Image/seafood.png",
  },
  {
    item_name: "Top Eats",
    item_image: "/Assets/Img/uber_Image/top_eats.png",
  },
  {
    item_name: "Grocery",
    item_image: "/Assets/Img/uber_Image/uber_grocery.png",
  },
  {
    item_name: "Asian",
    item_image: "/Assets/Img/uber_Image/asian.png",
  },
  {
    item_name: "Name",
    item_image: "/Assets/Img/uber_Image/uber_Img.png",
  },
  {
    item_name: "Coffee & Tea",
    item_image: "/Assets/Img/uber_Image/coffeeandtea.png",
  },
  {
    item_name: "Convenience",
    item_image: "/Assets/Img/uber_Image/convenience.png",
  },
  {
    item_name: "FastFood",
    item_image: "/Assets/Img/uber_Image/fastfood.png",
  },
  {
    item_name: "Indian",
    item_image: "/Assets/Img/uber_Image/indian.png",
  },
  {
    item_name: "Italian",
    item_image: "/Assets/Img/uber_Image/italian.png",
  },
  {
    item_name: "SeaFood",
    item_image: "/Assets/Img/uber_Image/seafood.png",
  },
  {
    item_name: "Top Eats",
    item_image: "/Assets/Img/uber_Image/top_eats.png",
  },
  {
    item_name: "Grocery",
    item_image: "/Assets/Img/uber_Image/uber_grocery.png",
  },
];

export const FoodItem = [
  {
    item_name: "Barger",
    item_image: "/Assets/Img/barger.png",
  },
  {
    item_name: "Biriyani",
    item_image: "/Assets/Img/biriyani.png",
  },
  {
    item_name: "Chaowmin",
    item_image: "/Assets/Img/chaowmin.png",
  },
  {
    item_name: "Nachos",
    item_image: "/Assets/Img/nachos.png",
  },
  {
    item_name: "Pizza",
    item_image: "/Assets/Img/pizza.png",
  },
  {
    item_name: "Roll Chicken",
    item_image: "/Assets/Img/roll_chicken.png",
  },
];

export const Two_one = [
  {
    item_name: "Barger",
    item_image: "/Assets/Img/barger.png",
  },
  {
    item_name: "Biriyani",
    item_image: "/Assets/Img/biriyani.png",
  },
];

export const Four_two = [
  {
    item_name: "Barger",
    item_image: "/Assets/Img/barger.png",
  },
  {
    item_name: "Biriyani",
    item_image: "/Assets/Img/biriyani.png",
  },
  {
    item_name: "Chaowmin",
    item_image: "/Assets/Img/chaowmin.png",
  },
  {
    item_name: "Nachos",
    item_image: "/Assets/Img/nachos.png",
  },
];
